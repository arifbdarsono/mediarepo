#!/bin/bash
# Script to configure audio for Chrome Remote Desktop on Xubuntu
# This script should be run as the user who will be using Chrome Remote Desktop

# Ensure PulseAudio is installed
if ! command -v pulseaudio &> /dev/null; then
    echo "PulseAudio is not installed. Installing..."
    sudo apt-get update
    sudo apt-get install -y pulseaudio pulseaudio-utils
fi

# Create PulseAudio configuration directory if it doesn't exist
mkdir -p ~/.config/pulse

# Create PulseAudio client configuration
cat > ~/.config/pulse/client.conf << EOF
# Connect to the host's PulseAudio server
default-server = unix:/tmp/pulse-socket
autospawn = no
daemon-binary = /bin/true
enable-memfd = yes
EOF

# Create a systemd user service for PulseAudio
mkdir -p ~/.config/systemd/user/
cat > ~/.config/systemd/user/pulseaudio.service << EOF
[Unit]
Description=PulseAudio Sound System
After=network.target

[Service]
ExecStart=/usr/bin/pulseaudio --start
Restart=always
RestartSec=30

[Install]
WantedBy=default.target
EOF

# Enable and start the service
systemctl --user daemon-reload
systemctl --user enable pulseaudio.service
systemctl --user start pulseaudio.service

# Configure Chrome Remote Desktop to use PulseAudio
# Check if Chrome Remote Desktop is installed
if [ -f /opt/google/chrome-remote-desktop/chrome-remote-desktop ]; then
    # Backup the original file
    sudo cp /opt/google/chrome-remote-desktop/chrome-remote-desktop /opt/google/chrome-remote-desktop/chrome-remote-desktop.bak
    
    # Modify the Chrome Remote Desktop script to use PulseAudio
    sudo sed -i 's/PULSE_RUNTIME_PATH=/PULSE_RUNTIME_PATH=\/tmp\/pulse-socket/g' /opt/google/chrome-remote-desktop/chrome-remote-desktop
    
    # Restart Chrome Remote Desktop service
    sudo service chrome-remote-desktop restart
else
    echo "Chrome Remote Desktop is not installed. Please install it first."
    echo "Visit: https://remotedesktop.google.com/access to download and install."
fi

# Add audio configuration to .xsessionrc to ensure it's loaded on session start
cat > ~/.xsessionrc << EOF
# PulseAudio configuration for Chrome Remote Desktop
export PULSE_SERVER=unix:/tmp/pulse-socket
EOF

echo "Audio configuration for Chrome Remote Desktop completed."
echo "Please restart your Chrome Remote Desktop session for changes to take effect."