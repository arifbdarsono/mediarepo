# Configuring Audio for Chrome Remote Desktop on Xubuntu

This guide will help you set up audio playback for Chrome Remote Desktop on Xubuntu.

## Prerequisites

- Xubuntu installed on your system
- Chrome Remote Desktop installed
- Administrative (sudo) privileges

## Automatic Setup

1. Download the setup script:
   ```bash
   wget -O chrome_remote_desktop_audio_setup.sh https://raw.githubusercontent.com/yourusername/scripts/main/chrome_remote_desktop_audio_setup.sh
   ```

2. Make the script executable:
   ```bash
   chmod +x chrome_remote_desktop_audio_setup.sh
   ```

3. Run the script:
   ```bash
   ./chrome_remote_desktop_audio_setup.sh
   ```

4. Restart your Chrome Remote Desktop session.

## Manual Setup

If you prefer to set up manually or if the script doesn't work, follow these steps:

### 1. Install PulseAudio

```bash
sudo apt-get update
sudo apt-get install -y pulseaudio pulseaudio-utils
```

### 2. Configure PulseAudio for Chrome Remote Desktop

Create a PulseAudio client configuration file:

```bash
mkdir -p ~/.config/pulse
```

Create or edit `~/.config/pulse/client.conf`:

```
default-server = unix:/tmp/pulse-socket
autospawn = no
daemon-binary = /bin/true
enable-memfd = yes
```

### 3. Create a systemd user service for PulseAudio

```bash
mkdir -p ~/.config/systemd/user/
```

Create `~/.config/systemd/user/pulseaudio.service`:

```
[Unit]
Description=PulseAudio Sound System
After=network.target

[Service]
ExecStart=/usr/bin/pulseaudio --start
Restart=always
RestartSec=30

[Install]
WantedBy=default.target
```

Enable and start the service:

```bash
systemctl --user daemon-reload
systemctl --user enable pulseaudio.service
systemctl --user start pulseaudio.service
```

### 4. Modify Chrome Remote Desktop Configuration

Backup the original file:

```bash
sudo cp /opt/google/chrome-remote-desktop/chrome-remote-desktop /opt/google/chrome-remote-desktop/chrome-remote-desktop.bak
```

Edit the Chrome Remote Desktop script:

```bash
sudo sed -i 's/PULSE_RUNTIME_PATH=/PULSE_RUNTIME_PATH=\/tmp\/pulse-socket/g' /opt/google/chrome-remote-desktop/chrome-remote-desktop
```

Restart Chrome Remote Desktop service:

```bash
sudo service chrome-remote-desktop restart
```

### 5. Configure Session Environment

Create or edit `~/.xsessionrc`:

```bash
# PulseAudio configuration for Chrome Remote Desktop
export PULSE_SERVER=unix:/tmp/pulse-socket
```

## Troubleshooting

### No Audio After Setup

1. Check if PulseAudio is running:
   ```bash
   pulseaudio --check
   ```

2. If not running, start it:
   ```bash
   pulseaudio --start
   ```

3. Check PulseAudio status:
   ```bash
   pactl info
   ```

4. Verify the socket exists:
   ```bash
   ls -la /tmp/pulse-socket
   ```

### Audio Crackling or Distortion

1. Edit `/etc/pulse/daemon.conf`:
   ```bash
   sudo nano /etc/pulse/daemon.conf
   ```

2. Add or modify these lines:
   ```
   default-sample-rate = 44100
   default-fragments = 8
   default-fragment-size-msec = 10
   ```

3. Restart PulseAudio:
   ```bash
   pulseaudio -k
   pulseaudio --start
   ```

### Chrome Remote Desktop Not Detecting Audio

1. Make sure Chrome Remote Desktop service is running:
   ```bash
   sudo service chrome-remote-desktop status
   ```

2. Restart the service:
   ```bash
   sudo service chrome-remote-desktop restart
   ```

3. Check if the audio device is visible:
   ```bash
   pactl list sinks
   ```

## Additional Configuration

### Setting Default Audio Device

If you have multiple audio devices, set the default one:

```bash
pactl set-default-sink [SINK_NAME]
```

Replace `[SINK_NAME]` with the name of your preferred audio device from `pactl list sinks`.

### Enabling Microphone

To enable microphone input:

1. List available sources:
   ```bash
   pactl list sources
   ```

2. Set default source:
   ```bash
   pactl set-default-source [SOURCE_NAME]
   ```

## References

- [PulseAudio Documentation](https://www.freedesktop.org/wiki/Software/PulseAudio/Documentation/)
- [Chrome Remote Desktop Help](https://support.google.com/chrome/answer/1649523)