# Chrome Remote Desktop Audio Configuration for Xubuntu

This repository contains configuration files and scripts to enable audio playback in Chrome Remote Desktop sessions on Xubuntu.

## Files Included

1. `chrome_remote_desktop_audio_setup.sh` - Automated setup script
2. `chrome_remote_desktop_audio_guide.md` - Detailed guide with manual steps and troubleshooting
3. `pulse-client.conf` - PulseAudio client configuration
4. `pulseaudio.service` - Systemd user service for PulseAudio
5. `daemon.conf` - PulseAudio daemon configuration with optimized settings

## Quick Setup

1. Download all files to your local machine
2. Make the setup script executable:
   ```bash
   chmod +x chrome_remote_desktop_audio_setup.sh
   ```
3. Run the setup script:
   ```bash
   ./chrome_remote_desktop_audio_setup.sh
   ```
4. Restart your Chrome Remote Desktop session

## Manual Setup

If you prefer to set up manually or need more control:

1. Copy `pulse-client.conf` to `~/.config/pulse/client.conf`
2. Copy `daemon.conf` to `~/.config/pulse/daemon.conf`
3. Copy `pulseaudio.service` to `~/.config/systemd/user/pulseaudio.service`
4. Enable and start the PulseAudio service:
   ```bash
   systemctl --user daemon-reload
   systemctl --user enable pulseaudio.service
   systemctl --user start pulseaudio.service
   ```
5. Configure Chrome Remote Desktop to use PulseAudio (see detailed guide)

## Troubleshooting

For detailed troubleshooting steps, refer to the `chrome_remote_desktop_audio_guide.md` file.

## System Requirements

- Xubuntu (or other Ubuntu-based distributions with XFCE)
- PulseAudio installed
- Chrome Remote Desktop installed
- User with sudo privileges

## Notes

- These configurations are specifically designed for Chrome Remote Desktop on Xubuntu
- Some settings may need adjustment based on your specific hardware and network conditions
- The setup script must be run as the user who will be using Chrome Remote Desktop, not as root